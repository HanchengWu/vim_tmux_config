import numpy as np
import random

def label_generator():
    select = np.random.rand()
    return np.random.rand() if select >= 0.5 else random.uniform(1,4)

def feature_generator(sample_size, feature_size):
    feature = 6000 * np.random.rand(sample_size, feature_size)
    return feature

# dataset parameters
sample_size = 10000
feature_size = 40
select_feature_size = 25

# tree parameters
num_of_trees = 20
max_depth = 6
max_leaf_nodes = 12

# ============== Generate simulated dataset ========
feature = feature_generator(sample_size, feature_size)
feature_name = np.array(['kc1','kc2','kc3','kc4','kc5','kc6','kc7','kc8','kc9','kc10',
                         'kc11','kc12','kc13','kc14','kc15','kc16','kc17','kc18','kc19',
                         'kc20','kc21','kc22','kc23','kc24','kc25','kc26','kc27','kc28',
                         'kc29','kc30','kc31','kc32','kc33','kc34','kc35','kc36','kc37',
                         'kc38','kc39','kc40']).reshape((1,-1))
label = np.asarray([label_generator() for i in range(sample_size)]).reshape((-1,1))
label_name = np.array(['wave64_wave32_ratio']).reshape((1,-1))
header = np.concatenate((label_name, feature_name), axis=1).tolist()
header = ','.join(header[0])

# print(label)
# print(feature)

data = np.concatenate((label, feature), axis=1)
#np.savetxt("data.csv", data, delimiter=",")

with open("big_file.csv", 'w') as f:
    f.write(header + '\n')
    np.savetxt(f, data, delimiter=",")


# ================ Generate train/test data =========
full_data = np.genfromtxt('big_file.csv',delimiter=',',skip_header=1)
label = full_data[:,0]

select_index = random.sample(range(1,feature_size+1),k=select_feature_size)
select_feature = full_data[:,select_index]
select_header = ['kc'+str(i) for i in select_index]
select_feature_name = np.asarray(select_header)
select_header = 'wave64_wave32_ratio,'+','.join(select_header)


# ================ Random Forest ====================
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics

X_train, X_test, y_train, y_test = train_test_split(select_feature, label, test_size=0.2)

# save the data
train_set = np.concatenate((y_train.reshape((-1,1)),X_train), axis=1)
np.savetxt("train.csv",train_set, delimiter=",",header=select_header)

test_set = np.concatenate((y_test.reshape((-1,1)),X_test), axis=1)
np.savetxt("test.csv",test_set,delimiter=",",header=select_header)

regressor = RandomForestRegressor(n_estimators=20, max_depth=max_depth, max_leaf_nodes=max_leaf_nodes, random_state=0)
regressor.fit(X_train, y_train)
y_pred = regressor.predict(X_test)

print('Mean Absolute Error:', metrics.mean_absolute_error(y_test, y_pred))
print('Mean Squared Error:', metrics.mean_squared_error(y_test, y_pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))

estimator = regressor.estimators_[5]

from sklearn.tree import export_graphviz
# Export as dot file:w
export_graphviz(estimator, out_file='rf_tree.dot', 
                feature_names = select_feature_name,
                class_names = label_name,
                rounded = True, proportion = False, 
                precision = 2, filled = True)



